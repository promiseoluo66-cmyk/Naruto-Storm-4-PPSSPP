# Naruto Storm 4 PPSSPP

**Naruto Ultimate Ninja Storm 4-inspired 3D fighting game for Sony PSP (runs on PPSSPP).**

Original prototype. No proprietary Storm 4 assets are included.

## Current Status – Improved Phase 1

### Working systems
- Full PSP project structure + Makefile + GitHub Actions workflow
- Main game loop with state machine
- PSP input (D-Pad, buttons, L trigger)
- Main Menu with selection
- **Playable battle**: Hashirama vs Madara
- Real health bars + chakra bars on screen
- Simple fighter representation (colored blocks with hit flash)
- Player controls:
  - Left / Right – Move
  - ✕ (Cross) – Jump
  - △ (Triangle) – Basic attack
  - □ (Square) – Ninjutsu (Wood Dragon)
  - L – Guard
  - Start – Pause
- Enemy AI for Madara
- Win / Lose conditions + Story mission completion
- Character data for Hashirama & Madara (code + JSON)
- Story Mode mission framework

### Still placeholder / next priorities
- Real 3D models and animations
- Font / text rendering
- More advanced camera and effects
- Additional missions and characters
- Sound

## Controls (Battle)

| Button       | Action          |
|--------------|-----------------|
| D-Pad / Stick| Move            |
| ✕            | Jump            |
| △            | Basic Attack    |
| □            | Ninjutsu        |
| L            | Guard           |
| Start        | Pause           |

## How to Build

Requires [PSPSDK / pspdev](https://github.com/pspdev/pspdev).

```bash
make clean
make
```

Copy the generated `EBOOT.PBP` into your PPSSPP `PSP/GAME/NarutoStorm4/` folder.

## Project Layout

```
src/          → C source
include/      → Headers
data/         → Character & mission JSON
assets/       → Future models / textures / audio
.github/      → CI workflow that builds EBOOT.PBP
```

## Legal

Character names and Naruto IP belong to their respective owners.  
This is an independent fan prototype using only original code.
