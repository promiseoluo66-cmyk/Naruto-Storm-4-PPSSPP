#ifndef STORY_H
#define STORY_H

#include "common.h"
#include "character.h"

#define MAX_MISSIONS 32

typedef struct {
    int id;
    char name[64];
    char description[128];
    CharacterId player_char;
    CharacterId enemy_char;
    int chapter;
    int unlocked;
    int completed;
} MissionDef;

void story_init(void);
const MissionDef* story_get_mission(int id);
int story_get_mission_count(void);
void story_unlock_next(int completed_id);
void story_mark_completed(int id);
int story_is_unlocked(int id);

#endif // STORY_H