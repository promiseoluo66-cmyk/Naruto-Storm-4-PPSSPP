#ifndef CHARACTER_H
#define CHARACTER_H

#include "common.h"

#define MAX_MOVES 8
#define MAX_NAME  32

typedef enum {
    CHAR_HASHIRAMA = 0,
    CHAR_MADARA,
    CHAR_NARUTO,
    CHAR_SASUKE,
    CHAR_COUNT
} CharacterId;

typedef struct {
    char name[MAX_NAME];
    float damage;
    float chakra_cost;
    float cooldown;
    int   type; // 0 = basic, 1 = ninjutsu, 2 = ultimate
} MoveDef;

typedef struct {
    CharacterId id;
    char name[MAX_NAME];
    float max_health;
    float max_chakra;
    float speed;
    float attack;
    float defense;
    MoveDef moves[MAX_MOVES];
    int move_count;
    // Future: animation / model references
} CharacterDef;

// Runtime instance
typedef struct {
    const CharacterDef* def;
    float health;
    float chakra;
    Vec3  position;
    Vec3  velocity;
    float facing;      // radians
    int   state;       // idle, attack, guard, hit, etc.
    float state_timer;
    float move_cooldown[MAX_MOVES];
    int   is_player;
} Fighter;

void character_system_init(void);
const CharacterDef* character_get(CharacterId id);
void fighter_init(Fighter* f, CharacterId id, int is_player, float x, float z);
void fighter_update(Fighter* f, float dt);
void fighter_take_damage(Fighter* f, float amount);
int  fighter_is_alive(const Fighter* f);

#endif // CHARACTER_H