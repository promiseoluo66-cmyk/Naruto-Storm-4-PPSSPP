#ifndef GRAPHICS_H
#define GRAPHICS_H

#include "common.h"

// Simple 2D drawing helpers for Phase 1/2 (GU based)

void gfx_draw_rect(float x, float y, float w, float h, unsigned int color);
void gfx_draw_rect_outline(float x, float y, float w, float h, unsigned int color);
void gfx_draw_health_bar(float x, float y, float w, float h, float ratio, unsigned int fill_color, unsigned int bg_color);
void gfx_draw_chakra_bar(float x, float y, float w, float h, float ratio);

// Color macros (ABGR for GU)
#define COLOR_WHITE   0xFFFFFFFF
#define COLOR_BLACK   0xFF000000
#define COLOR_RED     0xFF0000FF
#define COLOR_GREEN   0xFF00FF00
#define COLOR_BLUE    0xFFFF0000
#define COLOR_YELLOW  0xFF00FFFF
#define COLOR_ORANGE  0xFF0080FF
#define COLOR_CYAN    0xFFFFFF00
#define COLOR_DARK    0xFF1A0A00
#define COLOR_UI_BG   0xCC000000
#define COLOR_HEALTH  0xFF22CC22
#define COLOR_HEALTH_BG 0xFF222222
#define COLOR_CHAKRA  0xFFCC8800

#endif