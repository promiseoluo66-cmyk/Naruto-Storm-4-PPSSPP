#ifndef COMMON_H
#define COMMON_H

#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <pspgu.h>
#include <pspgum.h>
#include <psppower.h>
#include <psprtc.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// Screen
#define SCREEN_WIDTH  480
#define SCREEN_HEIGHT 272
#define BUF_WIDTH     512

// Game states
typedef enum {
    STATE_MAIN_MENU = 0,
    STATE_STORY_SELECT,
    STATE_BATTLE,
    STATE_PAUSE,
    STATE_RESULT,
    STATE_OPTIONS
} GameState;

// Simple 3D vector
typedef struct {
    float x, y, z;
} Vec3;

// Color helper
typedef struct {
    unsigned char r, g, b, a;
} Color;

// Forward declarations
void game_init(void);
void game_update(float dt);
void game_render(void);
void game_shutdown(void);

void input_init(void);
void input_update(void);
int  input_pressed(unsigned int button);
int  input_held(unsigned int button);

void battle_init(int mission_id);
void battle_update(float dt);
void battle_render(void);
int  battle_is_finished(void);
int  battle_get_winner(void); // 0 = player, 1 = enemy, -1 = none

void story_init(void);
int  story_get_current_mission(void);
void story_complete_mission(int mission_id);
const char* story_get_mission_name(int mission_id);

#endif // COMMON_H