#include "story.h"

static MissionDef missions[MAX_MISSIONS];
static int mission_count = 0;

void story_init(void) {
    mission_count = 0;

    // Chapter 1 - Mission 0: Hashirama vs Madara (opening)
    MissionDef* m0 = &missions[mission_count++];
    m0->id = 0;
    strcpy(m0->name, "Hashirama vs Madara");
    strcpy(m0->description, "The legendary rivalry begins. First Hokage vs the Uchiha leader.");
    m0->player_char = CHAR_HASHIRAMA;
    m0->enemy_char = CHAR_MADARA;
    m0->chapter = 1;
    m0->unlocked = 1; // first mission unlocked
    m0->completed = 0;

    // Future missions (placeholders, locked)
    MissionDef* m1 = &missions[mission_count++];
    m1->id = 1;
    strcpy(m1->name, "The Fourth Great Ninja War Begins");
    strcpy(m1->description, "Allied Shinobi Forces assemble.");
    m1->player_char = CHAR_NARUTO;
    m1->enemy_char = CHAR_MADARA;
    m1->chapter = 2;
    m1->unlocked = 0;
    m1->completed = 0;

    MissionDef* m2 = &missions[mission_count++];
    m2->id = 2;
    strcpy(m2->name, "Obito and the Ten-Tails");
    strcpy(m2->description, "Naruto & Sasuke confront Obito.");
    m2->player_char = CHAR_NARUTO;
    m2->enemy_char = CHAR_MADARA; // temporary
    m2->chapter = 3;
    m2->unlocked = 0;
    m2->completed = 0;
}

const MissionDef* story_get_mission(int id) {
    if (id < 0 || id >= mission_count) return NULL;
    return &missions[id];
}

int story_get_mission_count(void) {
    return mission_count;
}

void story_unlock_next(int completed_id) {
    if (completed_id + 1 < mission_count) {
        missions[completed_id + 1].unlocked = 1;
    }
}

void story_mark_completed(int id) {
    if (id >= 0 && id < mission_count) {
        missions[id].completed = 1;
        story_unlock_next(id);
    }
}

int story_is_unlocked(int id) {
    if (id < 0 || id >= mission_count) return 0;
    return missions[id].unlocked;
}

const char* story_get_mission_name(int mission_id) {
    const MissionDef* m = story_get_mission(mission_id);
    return m ? m->name : "Unknown Mission";
}