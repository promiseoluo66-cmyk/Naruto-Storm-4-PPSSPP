#include "common.h"

// Simple third-person camera that follows the battle
static Vec3 cam_pos = {0.0f, 4.0f, 8.0f};
static Vec3 cam_target = {0.0f, 1.0f, 0.0f};

void camera_update(const Vec3* focus, float dt) {
    // Smooth follow – to be expanded
    cam_target.x = focus->x;
    cam_target.y = focus->y + 1.0f;
    cam_target.z = focus->z;

    cam_pos.x += (cam_target.x - cam_pos.x) * 2.0f * dt;
    cam_pos.z = cam_target.z + 8.0f;
}

void camera_apply(void) {
    // sceGumLookAt will be used here once full 3D pipeline is active
}