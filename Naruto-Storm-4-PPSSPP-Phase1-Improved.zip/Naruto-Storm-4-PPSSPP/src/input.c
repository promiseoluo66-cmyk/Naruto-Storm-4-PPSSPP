#include "common.h"

static SceCtrlData pad;
static unsigned int previous_buttons = 0;
static unsigned int current_buttons = 0;

void input_init(void) {
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    previous_buttons = 0;
    current_buttons = 0;
}

void input_update(void) {
    previous_buttons = current_buttons;
    sceCtrlReadBufferPositive(&pad, 1);
    current_buttons = pad.Buttons;
}

int input_pressed(unsigned int button) {
    return (current_buttons & button) && !(previous_buttons & button);
}

int input_held(unsigned int button) {
    return (current_buttons & button) != 0;
}

// Analog helpers (optional for later)
float input_analog_x(void) {
    return (pad.Lx - 128) / 128.0f;
}

float input_analog_y(void) {
    return (pad.Ly - 128) / 128.0f;
}