#include "common.h"
#include "character.h"

// Combat helpers – damage calculation, hit detection, etc.
// Expanded in Phase 2

float combat_calculate_damage(const Fighter* attacker, const MoveDef* move) {
    if (!attacker || !move) return 0.0f;
    return move->damage * attacker->def->attack;
}

int combat_check_hit(const Fighter* a, const Fighter* b, float range) {
    float dx = a->position.x - b->position.x;
    float dz = a->position.z - b->position.z;
    float dist = sqrtf(dx * dx + dz * dz);
    return dist <= range;
}