#include "common.h"

// Save / Load system – Phase 4
// Will use PSP memory stick save data

typedef struct {
    int magic;
    int version;
    int mission_progress[32];
    int unlocked_chars[16];
} SaveData;

int save_game(const SaveData* data) {
    // Placeholder
    (void)data;
    return 0;
}

int load_game(SaveData* data) {
    // Placeholder
    (void)data;
    return 0;
}