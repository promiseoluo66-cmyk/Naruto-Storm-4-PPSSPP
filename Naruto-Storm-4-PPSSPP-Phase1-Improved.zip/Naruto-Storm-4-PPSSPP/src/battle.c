#include "common.h"
#include "character.h"
#include "story.h"
#include "graphics.h"

static Fighter player;
static Fighter enemy;
static int battle_active = 0;
static int winner = -1;
static float battle_timer = 0.0f;
static int current_mission = 0;
static float hit_flash_player = 0.0f;
static float hit_flash_enemy = 0.0f;

void battle_init(int mission_id) {
    current_mission = mission_id;
    const MissionDef* m = story_get_mission(mission_id);
    if (!m) return;

    fighter_init(&player, m->player_char, 1, -3.5f, 0.0f);
    fighter_init(&enemy,  m->enemy_char,  0,  3.5f, 0.0f);

    battle_active = 1;
    winner = -1;
    battle_timer = 0.0f;
    hit_flash_player = 0.0f;
    hit_flash_enemy = 0.0f;
}

void battle_update(float dt) {
    if (!battle_active) return;

    battle_timer += dt;
    if (hit_flash_player > 0.0f) hit_flash_player -= dt;
    if (hit_flash_enemy > 0.0f) hit_flash_enemy -= dt;

    fighter_update(&player, dt);
    fighter_update(&enemy, dt);

    // ===== Player Controls =====
    float speed = player.def->speed * 4.2f;
    float ax = 0.0f;
    if (input_held(PSP_CTRL_LEFT))  ax = -1.0f;
    if (input_held(PSP_CTRL_RIGHT)) ax =  1.0f;

    if (ax != 0.0f) {
        player.position.x += ax * speed * dt;
        player.facing = (ax > 0) ? 0.0f : 3.14159f;
    }

    // Arena bounds
    if (player.position.x < -7.0f) player.position.x = -7.0f;
    if (player.position.x >  7.0f) player.position.x =  7.0f;

    // Jump
    if (input_pressed(PSP_CTRL_CROSS)) {
        if (player.position.y <= 0.05f) {
            player.velocity.y = 9.0f;
        }
    }

    // Guard (L)
    if (input_held(PSP_CTRL_LTRIGGER)) {
        player.state = 2;
        player.state_timer = 0.1f;
    }

    // Basic Attack (Triangle)
    if (input_pressed(PSP_CTRL_TRIANGLE)) {
        if (player.move_cooldown[0] <= 0.0f && player.state != 2) {
            player.state = 1;
            player.state_timer = 0.32f;
            player.move_cooldown[0] = player.def->moves[0].cooldown;

            float dist = fabsf(player.position.x - enemy.position.x);
            if (dist < 2.4f && fighter_is_alive(&enemy) && enemy.state != 2) {
                float dmg = player.def->moves[0].damage * player.def->attack;
                fighter_take_damage(&enemy, dmg);
                hit_flash_enemy = 0.25f;
            }
        }
    }

    // Ninjutsu (Square) - first special
    if (input_pressed(PSP_CTRL_SQUARE)) {
        if (player.def->move_count > 1 &&
            player.move_cooldown[1] <= 0.0f &&
            player.chakra >= player.def->moves[1].chakra_cost) {

            player.chakra -= player.def->moves[1].chakra_cost;
            player.state = 1;
            player.state_timer = 0.55f;
            player.move_cooldown[1] = player.def->moves[1].cooldown;

            float dist = fabsf(player.position.x - enemy.position.x);
            if (dist < 4.5f && fighter_is_alive(&enemy)) {
                float dmg = player.def->moves[1].damage * player.def->attack;
                fighter_take_damage(&enemy, dmg);
                hit_flash_enemy = 0.35f;
            }
        }
    }

    // ===== Enemy AI =====
    if (fighter_is_alive(&enemy)) {
        float dist = enemy.position.x - player.position.x;

        if (fabsf(dist) > 2.6f) {
            float dir = (dist > 0) ? -1.0f : 1.0f;
            enemy.position.x += dir * enemy.def->speed * 2.8f * dt;
            enemy.facing = (dir > 0) ? 0.0f : 3.14159f;
        } else if (enemy.state == 0 && enemy.move_cooldown[0] <= 0.0f) {
            enemy.state = 1;
            enemy.state_timer = 0.4f;
            enemy.move_cooldown[0] = 1.1f;

            if (player.state != 2) {
                float dmg = enemy.def->moves[0].damage * 0.75f;
                fighter_take_damage(&player, dmg);
                hit_flash_player = 0.25f;
            }
        }

        if (enemy.position.x < -7.0f) enemy.position.x = -7.0f;
        if (enemy.position.x >  7.0f) enemy.position.x =  7.0f;
    }

    // Chakra regeneration
    player.chakra += 8.0f * dt;
    if (player.chakra > player.def->max_chakra) player.chakra = player.def->max_chakra;
    enemy.chakra += 6.0f * dt;
    if (enemy.chakra > enemy.def->max_chakra) enemy.chakra = enemy.def->max_chakra;

    // Victory / Defeat
    if (!fighter_is_alive(&enemy)) {
        winner = 0;
        battle_active = 0;
        story_mark_completed(current_mission);
    } else if (!fighter_is_alive(&player)) {
        winner = 1;
        battle_active = 0;
    }
}

void battle_render(void) {
    // Ground line
    gfx_draw_rect(40.0f, 200.0f, 400.0f, 3.0f, 0xFF444444);

    // Player fighter (Hashirama - teal)
    float px = 240.0f + player.position.x * 28.0f;
    float py = 180.0f - player.position.y * 25.0f;
    unsigned int pcol = (hit_flash_player > 0.0f) ? COLOR_WHITE : 0xFF44AA66;
    if (player.state == 2) pcol = 0xFF88CCAA;
    gfx_draw_rect(px - 12.0f, py - 40.0f, 24.0f, 40.0f, pcol);
    gfx_draw_rect_outline(px - 12.0f, py - 40.0f, 24.0f, 40.0f, COLOR_WHITE);

    // Enemy fighter (Madara - purple/red)
    float ex = 240.0f + enemy.position.x * 28.0f;
    float ey = 180.0f - enemy.position.y * 25.0f;
    unsigned int ecol = (hit_flash_enemy > 0.0f) ? COLOR_WHITE : 0xFF6644AA;
    if (enemy.state == 1) ecol = 0xFFAA4488;
    gfx_draw_rect(ex - 12.0f, ey - 40.0f, 24.0f, 40.0f, ecol);
    gfx_draw_rect_outline(ex - 12.0f, ey - 40.0f, 24.0f, 40.0f, COLOR_WHITE);

    // ===== HUD =====
    // Player health + chakra (left)
    float phr = player.health / player.def->max_health;
    gfx_draw_health_bar(20.0f, 18.0f, 180.0f, 14.0f, phr, COLOR_HEALTH, COLOR_HEALTH_BG);
    float pcr = player.chakra / player.def->max_chakra;
    gfx_draw_chakra_bar(20.0f, 36.0f, 180.0f, 8.0f, pcr);

    // Enemy health + chakra (right)
    float ehr = enemy.health / enemy.def->max_health;
    gfx_draw_health_bar(280.0f, 18.0f, 180.0f, 14.0f, ehr, 0xFF4444FF, COLOR_HEALTH_BG);
    float ecr = enemy.chakra / enemy.def->max_chakra;
    gfx_draw_chakra_bar(280.0f, 36.0f, 180.0f, 8.0f, ecr);
}

int battle_is_finished(void) {
    return !battle_active && winner >= 0;
}

int battle_get_winner(void) {
    return winner;
}