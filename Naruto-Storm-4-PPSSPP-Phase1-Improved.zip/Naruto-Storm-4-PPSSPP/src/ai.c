#include "common.h"
#include "character.h"

// Basic AI controller – expanded in Phase 2
void ai_update(Fighter* self, const Fighter* target, float dt) {
    if (!self || !target || !fighter_is_alive(self)) return;

    float dx = target->position.x - self->position.x;
    float dist = fabsf(dx);

    if (dist > 2.8f) {
        // Approach
        self->position.x += (dx > 0 ? 1.0f : -1.0f) * self->def->speed * 2.2f * dt;
    } else if (self->state == 0 && self->move_cooldown[0] <= 0.0f) {
        // Attack
        self->state = 1;
        self->state_timer = 0.4f;
        self->move_cooldown[0] = 1.5f;
    }
}