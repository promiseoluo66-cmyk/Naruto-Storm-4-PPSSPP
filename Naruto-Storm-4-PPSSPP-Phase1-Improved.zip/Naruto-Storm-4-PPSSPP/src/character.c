#include "character.h"

static CharacterDef characters[CHAR_COUNT];

void character_system_init(void) {
    // ========== HASHIRAMA SENJU ==========
    CharacterDef* h = &characters[CHAR_HASHIRAMA];
    strcpy(h->name, "Hashirama Senju");
    h->id = CHAR_HASHIRAMA;
    h->max_health = 1200.0f;
    h->max_chakra = 100.0f;
    h->speed = 1.1f;
    h->attack = 1.15f;
    h->defense = 1.1f;
    h->move_count = 5;

    strcpy(h->moves[0].name, "Wood Style: Punch");
    h->moves[0].damage = 35.0f; h->moves[0].chakra_cost = 0; h->moves[0].cooldown = 0.4f; h->moves[0].type = 0;

    strcpy(h->moves[1].name, "Wood Dragon");
    h->moves[1].damage = 90.0f; h->moves[1].chakra_cost = 25; h->moves[1].cooldown = 4.0f; h->moves[1].type = 1;

    strcpy(h->moves[2].name, "Wood Golem");
    h->moves[2].damage = 110.0f; h->moves[2].chakra_cost = 35; h->moves[2].cooldown = 6.0f; h->moves[2].type = 1;

    strcpy(h->moves[3].name, "Sage Mode");
    h->moves[3].damage = 0; h->moves[3].chakra_cost = 40; h->moves[3].cooldown = 15.0f; h->moves[3].type = 1;

    strcpy(h->moves[4].name, "Sage Art: Shinsu Senju");
    h->moves[4].damage = 280.0f; h->moves[4].chakra_cost = 80; h->moves[4].cooldown = 20.0f; h->moves[4].type = 2;

    // ========== MADARA UCHIHA ==========
    CharacterDef* m = &characters[CHAR_MADARA];
    strcpy(m->name, "Madara Uchiha");
    m->id = CHAR_MADARA;
    m->max_health = 1250.0f;
    m->max_chakra = 110.0f;
    m->speed = 1.15f;
    m->attack = 1.2f;
    m->defense = 1.05f;
    m->move_count = 5;

    strcpy(m->moves[0].name, "Uchiha Style Combo");
    m->moves[0].damage = 38.0f; m->moves[0].chakra_cost = 0; m->moves[0].cooldown = 0.35f; m->moves[0].type = 0;

    strcpy(m->moves[1].name, "Fire Style: Majestic Destroyer Flame");
    m->moves[1].damage = 100.0f; m->moves[1].chakra_cost = 30; m->moves[1].cooldown = 5.0f; m->moves[1].type = 1;

    strcpy(m->moves[2].name, "Susanoo");
    m->moves[2].damage = 130.0f; m->moves[2].chakra_cost = 40; m->moves[2].cooldown = 7.0f; m->moves[2].type = 1;

    strcpy(m->moves[3].name, "Limbo");
    m->moves[3].damage = 70.0f; m->moves[3].chakra_cost = 25; m->moves[3].cooldown = 8.0f; m->moves[3].type = 1;

    strcpy(m->moves[4].name, "Perfect Susanoo");
    m->moves[4].damage = 300.0f; m->moves[4].chakra_cost = 85; m->moves[4].cooldown = 22.0f; m->moves[4].type = 2;

    // Placeholders for later
    CharacterDef* n = &characters[CHAR_NARUTO];
    strcpy(n->name, "Naruto Uzumaki");
    n->id = CHAR_NARUTO;
    n->max_health = 1100.0f;
    n->max_chakra = 120.0f;
    n->speed = 1.2f;
    n->attack = 1.1f;
    n->defense = 1.0f;
    n->move_count = 0;

    CharacterDef* s = &characters[CHAR_SASUKE];
    strcpy(s->name, "Sasuke Uchiha");
    s->id = CHAR_SASUKE;
    s->max_health = 1050.0f;
    s->max_chakra = 115.0f;
    s->speed = 1.25f;
    s->attack = 1.25f;
    s->defense = 0.95f;
    s->move_count = 0;
}

const CharacterDef* character_get(CharacterId id) {
    if (id < 0 || id >= CHAR_COUNT) return &characters[0];
    return &characters[id];
}

void fighter_init(Fighter* f, CharacterId id, int is_player, float x, float z) {
    f->def = character_get(id);
    f->health = f->def->max_health;
    f->chakra = f->def->max_chakra;
    f->position.x = x;
    f->position.y = 0.0f;
    f->position.z = z;
    f->velocity.x = f->velocity.y = f->velocity.z = 0.0f;
    f->facing = is_player ? 0.0f : 3.14159f;
    f->state = 0;
    f->state_timer = 0.0f;
    f->is_player = is_player;
    for (int i = 0; i < MAX_MOVES; i++) f->move_cooldown[i] = 0.0f;
}

void fighter_update(Fighter* f, float dt) {
    for (int i = 0; i < f->def->move_count; i++) {
        if (f->move_cooldown[i] > 0.0f) {
            f->move_cooldown[i] -= dt;
            if (f->move_cooldown[i] < 0.0f) f->move_cooldown[i] = 0.0f;
        }
    }
    if (f->state_timer > 0.0f) {
        f->state_timer -= dt;
        if (f->state_timer <= 0.0f) {
            f->state = 0;
            f->state_timer = 0.0f;
        }
    }
    // Simple gravity / ground
    if (f->position.y > 0.0f) {
        f->velocity.y -= 15.0f * dt;
        f->position.y += f->velocity.y * dt;
        if (f->position.y < 0.0f) {
            f->position.y = 0.0f;
            f->velocity.y = 0.0f;
        }
    }
}

void fighter_take_damage(Fighter* f, float amount) {
    float final = amount / f->def->defense;
    f->health -= final;
    if (f->health < 0.0f) f->health = 0.0f;
    f->state = 3; // hit
    f->state_timer = 0.4f;
}

int fighter_is_alive(const Fighter* f) {
    return f->health > 0.0f;
}