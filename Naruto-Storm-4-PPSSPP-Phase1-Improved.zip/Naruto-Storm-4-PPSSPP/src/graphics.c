#include "graphics.h"

// Vertex for GU (XYZ + Color)
typedef struct {
    unsigned int color;
    float x, y, z;
} Vertex;

void gfx_draw_rect(float x, float y, float w, float h, unsigned int color) {
    Vertex* v = (Vertex*)sceGuGetMemory(2 * sizeof(Vertex));
    v[0].color = color; v[0].x = x;     v[0].y = y;     v[0].z = 0.0f;
    v[1].color = color; v[1].x = x + w; v[1].y = y + h; v[1].z = 0.0f;

    sceGuDisable(GU_TEXTURE_2D);
    sceGuDisable(GU_DEPTH_TEST);
    sceGuDrawArray(GU_SPRITES, GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D, 2, 0, v);
    sceGuEnable(GU_DEPTH_TEST);
}

void gfx_draw_rect_outline(float x, float y, float w, float h, unsigned int color) {
    // Simple 1px outline using four thin rects
    gfx_draw_rect(x, y, w, 1.0f, color);
    gfx_draw_rect(x, y + h - 1.0f, w, 1.0f, color);
    gfx_draw_rect(x, y, 1.0f, h, color);
    gfx_draw_rect(x + w - 1.0f, y, 1.0f, h, color);
}

void gfx_draw_health_bar(float x, float y, float w, float h, float ratio, unsigned int fill_color, unsigned int bg_color) {
    if (ratio < 0.0f) ratio = 0.0f;
    if (ratio > 1.0f) ratio = 1.0f;

    gfx_draw_rect(x, y, w, h, bg_color);
    if (ratio > 0.01f) {
        gfx_draw_rect(x, y, w * ratio, h, fill_color);
    }
    gfx_draw_rect_outline(x, y, w, h, COLOR_WHITE);
}

void gfx_draw_chakra_bar(float x, float y, float w, float h, float ratio) {
    gfx_draw_health_bar(x, y, w, h, ratio, COLOR_CHAKRA, COLOR_HEALTH_BG);
}