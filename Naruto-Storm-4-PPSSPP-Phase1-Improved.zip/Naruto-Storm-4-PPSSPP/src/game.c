#include "common.h"
#include "character.h"
#include "story.h"
#include "graphics.h"

static GameState state = STATE_MAIN_MENU;
static int menu_selection = 0;
static const int menu_count = 4;
static float result_timer = 0.0f;

void game_init(void) {
    character_system_init();
    story_init();
    state = STATE_MAIN_MENU;
    menu_selection = 0;
    result_timer = 0.0f;
}

void game_update(float dt) {
    switch (state) {
        case STATE_MAIN_MENU:
            if (input_pressed(PSP_CTRL_UP)) {
                menu_selection--;
                if (menu_selection < 0) menu_selection = menu_count - 1;
            }
            if (input_pressed(PSP_CTRL_DOWN)) {
                menu_selection++;
                if (menu_selection >= menu_count) menu_selection = 0;
            }
            if (input_pressed(PSP_CTRL_CROSS) || input_pressed(PSP_CTRL_CIRCLE)) {
                if (menu_selection == 0) {
                    battle_init(0);
                    state = STATE_BATTLE;
                } else if (menu_selection == 3) {
                    sceKernelExitGame();
                }
            }
            break;

        case STATE_BATTLE:
            battle_update(dt);
            if (battle_is_finished()) {
                state = STATE_RESULT;
                result_timer = 0.0f;
            }
            if (input_pressed(PSP_CTRL_START)) {
                state = STATE_PAUSE;
            }
            break;

        case STATE_PAUSE:
            if (input_pressed(PSP_CTRL_START) || input_pressed(PSP_CTRL_CROSS)) {
                state = STATE_BATTLE;
            }
            if (input_pressed(PSP_CTRL_CIRCLE)) {
                state = STATE_MAIN_MENU;
            }
            break;

        case STATE_RESULT:
            result_timer += dt;
            if (input_pressed(PSP_CTRL_CROSS) || input_pressed(PSP_CTRL_CIRCLE) || result_timer > 8.0f) {
                state = STATE_MAIN_MENU;
            }
            break;

        default:
            break;
    }
}

void game_render(void) {
    switch (state) {
        case STATE_MAIN_MENU: {
            // Header
            gfx_draw_rect(0.0f, 0.0f, 480.0f, 52.0f, 0xFF1A0800);
            gfx_draw_rect(0.0f, 52.0f, 480.0f, 3.0f, COLOR_ORANGE);

            // Menu panel
            gfx_draw_rect(50.0f, 75.0f, 380.0f, 155.0f, COLOR_UI_BG);

            // Menu selection bars (visual stand-in until font system)
            for (int i = 0; i < menu_count; i++) {
                float y = 90.0f + i * 34.0f;
                if (i == menu_selection) {
                    gfx_draw_rect(60.0f, y - 6.0f, 360.0f, 28.0f, 0x55FF9900);
                    gfx_draw_rect(70.0f, y + 4.0f, 220.0f, 10.0f, COLOR_YELLOW);
                } else {
                    gfx_draw_rect(70.0f, y + 4.0f, 160.0f, 8.0f, 0xFF888888);
                }
            }

            // Footer
            gfx_draw_rect(0.0f, 250.0f, 480.0f, 22.0f, 0xFF0D0500);
            break;
        }

        case STATE_BATTLE:
            battle_render();
            break;

        case STATE_PAUSE:
            battle_render();
            gfx_draw_rect(0.0f, 0.0f, 480.0f, 272.0f, 0x99000000);
            gfx_draw_rect(130.0f, 95.0f, 220.0f, 75.0f, COLOR_UI_BG);
            gfx_draw_rect(150.0f, 115.0f, 180.0f, 14.0f, COLOR_YELLOW);
            gfx_draw_rect(160.0f, 140.0f, 160.0f, 8.0f, 0xFFAAAAAA);
            break;

        case STATE_RESULT: {
            battle_render();
            gfx_draw_rect(0.0f, 0.0f, 480.0f, 272.0f, 0xBB000000);

            int w = battle_get_winner();
            if (w == 0) {
                // Victory
                gfx_draw_rect(80.0f, 85.0f, 320.0f, 100.0f, 0xFF003300);
                gfx_draw_rect(100.0f, 105.0f, 280.0f, 20.0f, COLOR_GREEN);
                gfx_draw_rect(120.0f, 140.0f, 240.0f, 12.0f, 0xFFAAFFAA);
            } else {
                // Defeat
                gfx_draw_rect(80.0f, 85.0f, 320.0f, 100.0f, 0xFF330000);
                gfx_draw_rect(100.0f, 105.0f, 280.0f, 20.0f, COLOR_RED);
                gfx_draw_rect(120.0f, 140.0f, 240.0f, 12.0f, 0xFFFFAAAA);
            }
            break;
        }

        default:
            break;
    }
}

void game_shutdown(void) {
}